import java.util.*;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            String[] inputTokens = scanner.nextLine().split("[\\s]+");
            String firstElement = inputTokens[0];
            String secondElement = inputTokens[1];

            switch (i) {
                case 0:
                    firstElement = inputTokens[0] + " " + inputTokens[1];
                    secondElement = inputTokens[2];
                    Tuple<String, String> firstTuple = new Tuple<>(firstElement, secondElement);
                    System.out.println(firstTuple.getKey() + " -> " + firstTuple.getValue());
                    break;
                case 1:
                    int value = Integer.valueOf(secondElement);
                    Tuple<String, Integer> secondTuple = new Tuple<>(firstElement, value);
                    System.out.println(secondTuple.getKey() + " -> " + secondTuple.getValue());
                    break;
                case 2:
                    int key = Integer.valueOf(firstElement);
                    double tupleValue = Double.valueOf(secondElement);
                    Tuple<Integer, Double> thirdTuple = new Tuple<>(key, tupleValue);
                    System.out.println(thirdTuple.getKey() + " -> " + thirdTuple.getValue());
                    break;
            }
        }
    }
}