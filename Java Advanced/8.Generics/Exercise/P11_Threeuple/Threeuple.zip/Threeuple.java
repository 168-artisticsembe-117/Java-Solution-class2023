class Threeuple<K, V, V2> {

    private K key;

    private V value;

    private V2 secondValue;

    public Threeuple(K key, V value, V2 secondValue) {
        this.setKey(key);
        this.setValue(value);
        this.setSecondValue(secondValue);
    }

    public K getKey() {
        return key;
    }

    protected void setKey(K key) {
        this.key = key;
    }

    public V getValue() {
        return value;
    }

    protected void setValue(V value) {
        this.value = value;
    }

    public V2 getSecondValue() {
        return secondValue;
    }

    protected void setSecondValue(V2 secondValue) {
        this.secondValue = secondValue;
    }
}