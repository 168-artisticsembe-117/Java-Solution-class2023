import java.lang.reflect.Method;
import java.lang.reflect.TypeVariable;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException {
//        Jar<String> jarofStrings = new Jar<>();
//        jarofStrings.add("Pesho");
//        jarofStrings.add("Gosho");
//
//        String name = jarofStrings.remove();
//        System.out.println(name);

//        Class<Jar> c1 = Jar.class;
//        Method[] methods = c1.getDeclaredMethods();
//        TypeVariable<Class<Jar>>[] parameters = c1.getTypeParameters();
//        int a= parameters.length;
//        c1.getDeclaredMethod("add");
//
//        System.out.println(c1.getName());
    }
}
