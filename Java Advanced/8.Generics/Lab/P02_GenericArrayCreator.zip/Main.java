public class Main {
    public static void main(String[] args) {
        String[] array = ArrayCreator.create(String.class,5,"aas");
        System.out.println(array.length);
        Integer[] ints = ArrayCreator.create(5,3);
        System.out.println(ints.length);

    }


}

