package p01_Database;

import org.junit.Assert;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class DatabaseTests {

    private Database database;

    @Test
    public void constructorTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.database = new Database(array);
        Assert.assertEquals(9, this.database.getElements().length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void constructorEmptyTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{};
        this.database = new Database(array);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void constructorMaxSizeTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9,1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.database = new Database(array);
    }

    @Test
    public void addTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.database = new Database(array);
        this.database.add(10);
        Assert.assertEquals(10, database.getElements().length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addExceptionTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.database = new Database(array);
        this.database.add(null);
    }

    @Test
    public void removeTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        this.database = new Database(array);
        this.database.remove();
        Assert.assertEquals(8, this.database.getElements().length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void removeExceptionTest() throws OperationNotSupportedException {
        Integer[] array = new Integer[]{1};
        this.database = new Database(array);
        this.database.remove();
        this.database.remove();
    }
}
