package p02_ExtendedDatabase;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class DatabaseTests {

    private Database database;
    private Person john;

    @Before
    public void initialize() throws OperationNotSupportedException {
        this.john = new Person(1, "John");
        Person[] array = new Person[]{john};
        database = new Database(array);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void constructorEmptyTest() throws OperationNotSupportedException {
        new Database(new Person[]{});
    }

    @Test
    public void addTest() throws OperationNotSupportedException {
        Person bat = new Person(2, "Bat");
        Assert.assertEquals(1, database.getElements().length);
        database.add(bat);
        Assert.assertEquals(2, database.getElements().length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addDuplicateIdTest() throws OperationNotSupportedException {
        Person bat = new Person(1, "Bat");
        database.add(bat);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addWrongIdPersonTest() throws OperationNotSupportedException {
        Person bat = new Person(-1, "Bat");
        database.add(bat);
    }

    @Test
    public void removeTest() throws OperationNotSupportedException {
        database.remove();
        Assert.assertEquals(0, database.getElements().length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void removeExceptionTest() throws OperationNotSupportedException {
        database.remove();
        database.remove();
    }

    @Test
    public void findByUserFoundTest() throws OperationNotSupportedException {
        Person person = database.findByUsername("John");
        Assert.assertEquals(person.getId(), john.getId());
        Assert.assertEquals(person.getUsername(), john.getUsername());
    }

    @Test
    public void findByUserNotFoundTest() throws OperationNotSupportedException {
        Person person = database.findByUsername("George");
        Assert.assertNull(person);
    }

    @Test
    public void findByUserCaseSensitiveTest() throws OperationNotSupportedException {
        Person person = database.findByUsername("john");
        Assert.assertNull(person);
        person = database.findByUsername("JOHN");
        Assert.assertNull(person);
        person = database.findByUsername("John");
        Assert.assertEquals(person.getId(), john.getId());
        Assert.assertEquals(person.getUsername(), john.getUsername());
    }
}
