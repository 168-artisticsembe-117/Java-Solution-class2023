package p02_ExtendedDatabase;

import org.junit.Assert;
import org.junit.Test;

public class PersonTest {

    @Test
    public void constructorTest(){
        Person person = new Person(1, "Test");
        Assert.assertEquals(1, person.getId());
        Assert.assertEquals("Test", person.getUsername());
    }

}
