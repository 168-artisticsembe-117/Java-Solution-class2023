package p03_IteratorTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;

public class ListIteratorTests {

    private ListIterator listIterator;

    @Before
    public void initialize() throws OperationNotSupportedException {
        this.listIterator = new ListIterator("element1", "element2");
    }

    @Test(expected = OperationNotSupportedException.class)
    public void nullConstructorTest() throws OperationNotSupportedException {
        new ListIterator(null);
    }

    @Test
    public void hasNextTest() {
        Assert.assertTrue(listIterator.hasNext());
        listIterator.move();
        Assert.assertFalse(listIterator.hasNext());
    }

    @Test
    public void moveTest() {
        Assert.assertTrue(listIterator.move());
        Assert.assertFalse(listIterator.move());
    }

    @Test
    public void printTest() {
        Assert.assertEquals("element1", listIterator.print());
        Assert.assertTrue(listIterator.move());
        Assert.assertEquals("element2", listIterator.print());
        Assert.assertFalse(listIterator.move());
    }

    @Test(expected = IllegalStateException.class)
    public void printEmptyTest() throws OperationNotSupportedException {
        listIterator = new ListIterator(new String[]{});
        listIterator.print();
    }
}
