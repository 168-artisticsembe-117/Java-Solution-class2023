package p04_BubbleSortTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BubbleSortTest {

    private int[] array;
    private int[] sortedArray;

    @Before
    public void initialize() {
        array = new int[]{3, 5, 2, 1, 2, 3};
        sortedArray = new int[]{1, 2, 2, 3, 3, 5};
    }

    @Test
    public void sortTest() {
        Bubble.sort(array);
        for (int i = 0; i < array.length; i ++) {
            Assert.assertEquals(array[i], sortedArray[i]);
        }
    }
}
