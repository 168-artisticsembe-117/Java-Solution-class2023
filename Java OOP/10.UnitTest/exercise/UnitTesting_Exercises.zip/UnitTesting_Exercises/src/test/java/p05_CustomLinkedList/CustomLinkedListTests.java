package p05_CustomLinkedList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CustomLinkedListTests {

    private CustomLinkedList<String> list;

    @Before
    public void initialize() {
        this.list = new CustomLinkedList<>();
        this.list.add("1");
        this.list.add("2");
        this.list.add("3");
    }

    @Test
    public void getTest() {
        Assert.assertEquals("1", list.get(0));
        Assert.assertEquals("2", list.get(1));
        Assert.assertEquals("3", list.get(2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void getExceptionTest() {
        list.get(4);
    }

    @Test
    public void setTest() {
        Assert.assertEquals("3", list.get(2));
        list.set(2, "4");
        Assert.assertEquals("4", list.get(2));
        list.set(0, "5");
        Assert.assertEquals("5", list.get(0));
        Assert.assertEquals("4", list.get(2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void setExceptionTest() {
        list.set(100, "3");
    }
}

