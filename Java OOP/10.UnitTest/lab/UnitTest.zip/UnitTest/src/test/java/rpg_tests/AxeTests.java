package rpg_tests;

import org.junit.Before;
import org.junit.Test;
import rgb_lab.Axe;
import rgb_lab.Dummy;

import static org.junit.Assert.assertEquals;

public class AxeTests {

    private final static int AXE_ATTACK = 10;
    private final static int AXE_DURABILITY_TEN = 10;
    private final static int DUMMY_HEALTH = 100;
    private final static int DUMMY_EXP = 10;
    private final static int EXPECTED_DURABILITY = AXE_DURABILITY_TEN - 1;

    private Axe axe;
    private Dummy dummy;

    @Before
    public void initialize() {
        axe = new Axe(AXE_ATTACK, AXE_DURABILITY_TEN);
        dummy = new Dummy(DUMMY_HEALTH, DUMMY_EXP);
    }

    @Test
    public void weaponAttackLossDurability() {
        axe.attack(dummy);
        assertEquals("Wrong durability", EXPECTED_DURABILITY, axe.getDurabilityPoints());
    }

    @Test(expected = IllegalStateException.class)
    public void brokenWeaponCantAttack(){
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
    }
}
