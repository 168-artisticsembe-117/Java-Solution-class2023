package rpg_tests;

import org.junit.Before;
import org.junit.Test;
import rgb_lab.Axe;
import rgb_lab.Dummy;

import static org.junit.Assert.assertEquals;

public class DummyTests {

    private final static int AXE_ATTACK = 10;
    private final static int AXE_DURABILITY_TEN = 100;
    private final static int DUMMY_HEALTH = 100;
    private final static int DUMMY_EXP = 10;

    private final static int EXPECTED_ALIVE_DUMMY = DUMMY_HEALTH;
    private final static int EXPECTED_DEATH_DUMMY = 0;

    private Axe axe;
    private Dummy dummy;
    private Dummy deathDummy;


    @Before
    public void initialize() {
        axe = new Axe(AXE_ATTACK, AXE_DURABILITY_TEN);
        dummy = new Dummy(DUMMY_HEALTH, DUMMY_EXP);
        deathDummy = new Dummy(EXPECTED_DEATH_DUMMY, DUMMY_EXP);
    }


    @Test
    public void dummyHealthLossTest() {
        assertEquals(EXPECTED_ALIVE_DUMMY, dummy.getHealth());
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        assertEquals(EXPECTED_DEATH_DUMMY, dummy.getHealth());
    }

    @Test(expected = IllegalStateException.class)
    public void cantAttackDeathDummy() {
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
        axe.attack(dummy);
    }

    @Test
    public void deadDummyExp() {
        assertEquals(10, deathDummy.giveExperience());
    }

    @Test(expected = IllegalStateException.class)
    public void aliveDummyCantGiveExp() {
        dummy.giveExperience();
    }
}
