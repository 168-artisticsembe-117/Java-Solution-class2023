package rpg_tests;

import org.junit.Test;

import rgb_lab.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HeroTests {
    private final static int TARGET_EXP = 10;
    private final static int TARGET_HEALTH = 0;
    private final static int ATTACK_POINT = 10;
    private final static int DURABILITY_POINT = 0;
    private final static String HERO_NAME = "BAT";

    @Test
    public void attackGainsExperienceWhenTargetDied() {
        Target target = new Target() {
            @Override
            public void takeAttack(int attackPoints) {}

            @Override
            public int getHealth() {
                return TARGET_HEALTH;
            }

            @Override
            public int giveExperience() {
                return TARGET_EXP;
            }

            @Override
            public boolean isDead() {
                return true;
            }
        };

        Weapon weapon = new Weapon() {
            @Override
            public void attack(Target target) {}

            @Override
            public int getAttackPoints() {
                return ATTACK_POINT;
            }

            @Override
            public int getDurabilityPoints() {
                return DURABILITY_POINT;
            }
        };

        Hero hero = new Hero(HERO_NAME, weapon);
        hero.attack(target);
        assertEquals("Wrong exp", 10, hero.getExperience());
    }


    @Test
    public void attackGainsExperienceWhenTargetDiedUsingMock() {
        Target dummy = mock(Target.class);
        Weapon axe = mock(Weapon.class);
        when(dummy.isDead()).thenReturn(true);
        when(dummy.giveExperience()).thenReturn(TARGET_EXP);

        Hero hero = new Hero(HERO_NAME, axe);
        hero.attack(dummy);
        assertEquals("Wrong exp", 10, hero.getExperience());
    }

}
