package zoo;

public class Main {
    public static void main(String[] args) {
        Bear bear = new Bear("Tedi Bear");

        System.out.println(bear.getName());
    }
}
