package zoo;

public class Mammal extends Animal {
    Mammal(String name) {
        super(name);
    }
}
