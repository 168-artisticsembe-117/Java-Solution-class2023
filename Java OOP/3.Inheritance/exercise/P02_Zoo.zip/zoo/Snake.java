package zoo;

public class Snake extends Reptile {
    Snake(String name) {
        super(name);
    }
}
