package hero;

public class DarkKnight extends Knight {
    DarkKnight(String username, int level) {
        super(username, level);
    }
}
