package hero;

public class DarkWizard extends Wizard {
    DarkWizard(String username, int level) {
        super(username, level);
    }
}
