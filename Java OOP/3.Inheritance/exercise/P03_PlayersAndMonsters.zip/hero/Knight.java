package hero;

public class Knight extends Hero {
    Knight(String username, int level) {
        super(username, level);
    }
}
