package hero;

public class MuseElf extends Elf {
    MuseElf(String username, int level) {
        super(username, level);
    }
}
