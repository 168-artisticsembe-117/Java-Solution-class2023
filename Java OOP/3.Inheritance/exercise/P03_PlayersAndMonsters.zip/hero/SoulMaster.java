package hero;

public class SoulMaster extends DarkWizard {
    SoulMaster(String username, int level) {
        super(username, level);
    }
}
