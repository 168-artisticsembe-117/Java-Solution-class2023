package hero;

public class Wizard extends Hero {
    Wizard(String username, int level) {
        super(username, level);
    }
}
