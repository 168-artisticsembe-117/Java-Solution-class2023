package restaurant;

import restaurant.beverage.Coffee;
import restaurant.food.Cake;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        Coffee coffee = new Coffee("Lavazza", 1.2);

        System.out.println(coffee.getName());
        System.out.println(coffee.getPrice());
        System.out.println(coffee.getCaffeine());
        System.out.println(coffee.getMilliliters());
    }
}
