package animals;

public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("Kotka", 10, "Male");

        System.out.println(cat.produceSound());
        System.out.println(cat.getName());
        System.out.println(cat.getAge());
        System.out.println(cat.getGender());
        System.out.println();
        System.out.println(cat);
    }
}
