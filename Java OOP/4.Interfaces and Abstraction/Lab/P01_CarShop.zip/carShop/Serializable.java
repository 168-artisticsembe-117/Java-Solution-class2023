package carShop;

public interface Serializable {

}
