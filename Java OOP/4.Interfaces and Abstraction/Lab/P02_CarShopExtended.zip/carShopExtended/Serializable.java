package carShopExtended;

public interface Serializable {

}
