package sayHelloExtended;

public interface Person {
    String getName();

    String sayHello();
}
