package ferrari;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        String name = scr.nextLine();
        Ferrari ferrari = new Ferrari(name);
        System.out.printf("%s/%s/%s/%s",
                ferrari.getModel(),
                ferrari.brakes(),
                ferrari.gas(),
                ferrari.getDriverName());
    }
}
