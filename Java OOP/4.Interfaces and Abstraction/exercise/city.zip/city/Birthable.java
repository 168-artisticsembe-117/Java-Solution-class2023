package city;

public interface Birthable {
    String getBirthDate();
}
