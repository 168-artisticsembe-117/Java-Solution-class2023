package city;

public interface Identifiable {
    String getId();
}
