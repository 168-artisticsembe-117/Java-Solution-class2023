package city;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String command = scanner.nextLine();
        List<Birthable> list = new ArrayList<>();
        while (!"End".equals(command)) {
            String[] inputs = command.split(" ");
            switch (inputs[0]) {
                case "Citizen":
                    Birthable citizin = new Citizen(inputs[1], Integer.parseInt(inputs[2]), inputs[3], inputs[4]);
                    list.add(citizin);
                    break;
                case "Pet":
                    Birthable pet = new Pet(inputs[1], inputs[2]);
                    list.add(pet);
                    break;
            }
            command = scanner.nextLine();
        }
        String checkYear = scanner.nextLine();
        list.stream().filter(x ->
                x.getBirthDate().substring(x.getBirthDate().length() - 4).equals(checkYear))
                .forEach(x -> System.out.println(x.getBirthDate()));
    }
}
