package city2;

public interface Identifiable {
    String getId();
}
