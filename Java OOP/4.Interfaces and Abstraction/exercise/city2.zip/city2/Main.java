package city2;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        Map<String, Buyer> people = new HashMap<>();
        for (; n > 0; n--) {
            String[] inputs = scanner.nextLine().split(" ");
            if (inputs.length == 4) {
                Buyer citizin = new Citizen(inputs[0], Integer.parseInt(inputs[1]), inputs[2], inputs[3]);
                people.putIfAbsent(inputs[0], citizin);
            } else {
                Buyer rebel = new Rebel(inputs[0], Integer.parseInt(inputs[1]), inputs[2]);
                people.putIfAbsent(inputs[0], rebel);
            }
        }
        String name = scanner.nextLine();
        while (!"End".equals(name)) {
            if (people.containsKey(name)) {
                people.get(name).buyFood();
            }
            name = scanner.nextLine();
        }
        System.out.println(people.entrySet().stream().
                mapToInt(x -> x.getValue().getFood())
                .sum());

    }
}
