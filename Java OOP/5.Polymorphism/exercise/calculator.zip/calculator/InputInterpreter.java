package calculator;

import javax.sound.midi.MetaMessage;

public class InputInterpreter {
    private CalculationEngine engine;
    private MemoryStorage memoryStorage;

    public InputInterpreter(CalculationEngine engine){
        this.engine = engine;
    }

    public boolean interpret(String input) {
        try {
            engine.pushNumber(Integer.parseInt(input));
        }catch (Exception ex){
            engine.pushOperation(this.getOperation(input));
        }
        return true;
    }
    public Operation getOperation(String operation) {
        switch (operation) {
            case "*": return new MultiplicationOperation();
            case "/": return new DivisionOperation();
            case "ms":
                if(memoryStorage == null)
                    memoryStorage = new MemoryStorage();
                return memoryStorage;
            case "mr":
                return new MemoryRecallOperation(memoryStorage);
            default:
                return null;
        }
    }
}
