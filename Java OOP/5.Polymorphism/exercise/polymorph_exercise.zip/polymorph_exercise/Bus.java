package polymorph_exercise;

import java.text.DecimalFormat;

public class Bus extends Vehicle{
    private final static double AIR_CONDITION_CONSUPTION = 1.4;

    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity, AIR_CONDITION_CONSUPTION);
    }


}
