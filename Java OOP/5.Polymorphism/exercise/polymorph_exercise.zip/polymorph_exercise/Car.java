package polymorph_exercise;

public class Car extends Vehicle{
    private final static double AIR_CONDITION_CONSUPTION = 0.9;

    public Car(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity, AIR_CONDITION_CONSUPTION);
    }
}
