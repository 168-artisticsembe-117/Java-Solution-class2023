package polymorph_exercise;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] carData = scanner.nextLine().split(" ");
        Vehicle car = new Car(Double.parseDouble(carData[1]), Double.parseDouble(carData[2]), Double.parseDouble(carData[3]));
        String[] truckData = scanner.nextLine().split(" ");
        Vehicle truck = new Truck(Double.parseDouble(truckData[1]), Double.parseDouble(truckData[2]), Double.parseDouble(truckData[3]));
        String[] busData = scanner.nextLine().split(" ");
        Vehicle bus = new Bus(Double.parseDouble(busData[1]), Double.parseDouble(busData[2]), Double.parseDouble(busData[3]));

        int n = Integer.parseInt(scanner.nextLine());
        for (; n > 0; n--) {
            String[] command = scanner.nextLine().split(" ");
            switch (command[0]) {
                case "Drive":
                    if("Car".equals(command[1]))
                        car.drive(Double.parseDouble(command[2]));
                    else if("Truck".equals(command[1]))
                        truck.drive(Double.parseDouble(command[2]));
                    else
                        bus.drive(Double.parseDouble(command[2]));
                    break;
                case "Refuel":
                    if("Car".equals(command[1]))
                        car.refuel(Double.parseDouble(command[2]));
                    else if("Truck".equals(command[1]))
                        truck.refuel(Double.parseDouble(command[2]));
                    else
                        bus.refuel(Double.parseDouble(command[2]));
                    break;
                case "DriveEmpty":
                    bus.drive(Double.parseDouble(command[2]), true);
                    break;
            }
        }
        System.out.println(car);
        System.out.println(truck);
        System.out.println(bus);
    }
}
