package polymorph_exercise;

public class Truck extends Vehicle{
    private final static double AIR_CONDITION_CONSUPTION = 1.6;

    public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity, AIR_CONDITION_CONSUPTION);
    }

    @Override
    public void refuel(double fuel) {
        if(fuel <= 0) {
            System.out.println("Fuel must be a positive number");
        } else if(fuelQuantity + fuel > tankCapacity) {
            System.out.println("Cannot fit fuel in tank");
        } else
            fuelQuantity += fuel * 0.95;
    }
}
