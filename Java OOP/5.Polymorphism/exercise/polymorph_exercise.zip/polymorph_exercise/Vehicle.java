package polymorph_exercise;

import java.text.DecimalFormat;

public abstract class Vehicle {
    private double airCondition;
    protected double fuelQuantity;
    protected double fuelConsumption;
    protected double tankCapacity;

    public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity, double airCondition) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
        this.tankCapacity = tankCapacity;
        this.airCondition = airCondition;
//        if(this.fuelQuantity > this.tankCapacity)
//            this.fuelQuantity = this.tankCapacity;
    }

    public void drive(double distance) {
        double fuel = distance * (fuelConsumption + airCondition);
        if(fuel <= fuelQuantity) {
            fuelQuantity -= fuel;
            DecimalFormat format = new DecimalFormat("#.#####");
            System.out.println(this.getClass().getSimpleName() + " travelled " + format.format(distance) + " km");
        } else {
            System.out.printf("%s needs refueling\n", this.getClass().getSimpleName());
        }
    }

    public void drive(double distance, boolean isEmpty) {
        double fuel = distance * (fuelConsumption + (isEmpty ? 0 : fuelConsumption));
        if(fuel <= fuelQuantity) {
            fuelQuantity -= fuel;
            DecimalFormat format = new DecimalFormat("#.#####");
            System.out.println(this.getClass().getSimpleName() + " travelled " + format.format(distance) + " km");
        } else {
            System.out.printf("%s needs refueling\n", this.getClass().getSimpleName());
        }
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f", this.getClass().getSimpleName(), this.fuelQuantity);
    }

    public void refuel(double fuel) {
        if(fuel <= 0) {
            System.out.println("Fuel must be a positive number");
        } else if(fuelQuantity + fuel > tankCapacity) {
            System.out.println("Cannot fit fuel in tank");
        } else
            fuelQuantity += fuel;
    }
}
