package wildfarm;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String command = scanner.nextLine();
        while (!"End".equals(command)) {
            String[] animalInfo = command.split(" ");
            String[] foodInfo = scanner.nextLine().split(" ");

            Animal animal = null;
            Food food = "Vegetable".equals(foodInfo[0])
                    ? new Vegetable(Integer.parseInt(foodInfo[1]))
                    : new Meat(Integer.parseInt(foodInfo[1]));

            switch (animalInfo[0]) {
                case "Cat":
                    animal = new Cat(animalInfo[0], animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3], animalInfo[4]);
                    break;
                case "Tiger":
                    animal = new Tiger(animalInfo[0], animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    break;
                case "Zebra":
                    animal = new Zebra(animalInfo[0], animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    break;
                case "Mouse":
                    animal = new Mouse(animalInfo[0], animalInfo[1], Double.parseDouble(animalInfo[2]), animalInfo[3]);
                    break;
            }
            animal.makeSound();
            animal.eat(food);
            System.out.println(animal);
            command = scanner.nextLine();
        }
    }
}
