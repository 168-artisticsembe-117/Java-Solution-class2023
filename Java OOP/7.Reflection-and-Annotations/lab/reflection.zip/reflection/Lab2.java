package reflection;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

public class Lab2 {
    public static void main(String[] args) {
        Class clazz = Reflection.class;
        Arrays.stream(clazz.getDeclaredMethods())
                .filter(x -> x.getName().startsWith("get"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(
                        x-> System.out.printf("%s will return class %s%n", x.getName(), x.getReturnType().getName())
                );
        Arrays.stream(clazz.getDeclaredMethods())
                .filter(x -> x.getName().startsWith("set"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(
                        x-> System.out.printf("%s and will set field of class %s%n", x.getName(),
                                Arrays.stream(x.getParameters()).map(p -> p.getType().getName()).collect(Collectors.joining(",")))
                );
    }
}
