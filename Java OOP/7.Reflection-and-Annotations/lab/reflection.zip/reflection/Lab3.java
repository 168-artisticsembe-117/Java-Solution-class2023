package reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Comparator;

public class Lab3 {
    public static void main(String[] args) {
        Class clazz = Reflection.class;
        Arrays.stream(clazz.getDeclaredFields())
                .filter(f -> !Modifier.isPrivate(f.getModifiers()))
                .sorted(Comparator.comparing(Field::getName))
                .forEach(f -> System.out.printf("%s must be private!%n", f.getName()));
        Arrays.stream(clazz.getDeclaredMethods())
                .filter(f -> !Modifier.isPublic(f.getModifiers()) && f.getName().startsWith("get"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(f -> System.out.printf("%s must be public!%n", f.getName()));
        Arrays.stream(clazz.getDeclaredMethods())
                .filter(f -> !Modifier.isPrivate(f.getModifiers()) && f.getName().startsWith("set"))
                .sorted(Comparator.comparing(Method::getName))
                .forEach(f -> System.out.printf("%s must be private!%n", f.getName()));
    }
}
